ElectroHub - E-commerce Website
==============================

HOW TO USE:
1. Unzip this folder
2. Double-click index.html - it will open in browser (Chrome recommended)
3. No internet / no server needed. Works offline. Data saves in browser localStorage.

FOR CUSTOMERS:
- Browse, Search, Filter, Wishlist, Cart, Checkout (COD / UPI / Card)
- My Orders - Track, Cancel, Return / Replace
- Coupons: WELCOME10 (10% off), ELECTRO500 (Rs 500 off above 10000), STUDENT15 (15% off above 5000)

FOR OWNER / ADMIN - HIDDEN:
1. Scroll to very bottom footer (downstrip)
2. Click tiny faint "Admin" link in bottom-right
3. Password: admin123
4. Inside Admin you can:
   - Add / Edit / Delete Products, set Price, MRP, Stock
   - Create Coupon Codes
   - Change Order Status
   - Approve / Reject Return / Replace requests
   - Change Store Name, Delivery Charge, Admin Password in Settings

TO DEPLOY ONLINE (FREE):
- Netlify: Go to netlify.com > Add new site > Deploy manually > Drag this whole folder
- Vercel: vercel.com > Add New > Upload this folder
- GitHub Pages: Upload index.html to repo > Settings > Pages
- Hostinger / Any hosting: Upload index.html to public_html

TO CHANGE STORE NAME / PHONE:
- Open index.html in Notepad / VS Code, search for ElectroHub / +91 90000 00000 and replace.

Made with single-file HTML + CSS + JS. All code in index.html.
